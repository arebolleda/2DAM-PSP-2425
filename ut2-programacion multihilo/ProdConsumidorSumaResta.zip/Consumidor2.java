public class Consumidor2 extends Thread {
    private final Queue2 cola;
    private final String tipo; // "suma" o "producto"

    public Consumidor2(Queue2 cola, String tipo) {
        this.cola = cola;
        this.tipo = tipo;
    }

    @Override
    public void run() {
        int acumulador = 1;
        
        if (tipo.equals("suma")) acumulador=0;

        try {
            for (int i = 0; i < 10; i++) {
                int numero = cola.get(tipo);
                if (tipo.equals("suma")) {
                    acumulador += numero;
                    System.out.println("Consumidor Suma: número leído = " + numero + ", suma total = " + acumulador);
                } else {
                    acumulador *= numero;
                    System.out.println("Consumidor Producto: número leído = " + numero + ", producto total = " + acumulador);
                }
                Thread.sleep(10000); // Simula el tiempo de consumo
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

