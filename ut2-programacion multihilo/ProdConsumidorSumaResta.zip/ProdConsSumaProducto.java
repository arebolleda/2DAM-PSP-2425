public class ProdConsSumaProducto {
    public static void main(String[] args) {
        Queue2 cola = new Queue2();

        Productor2 productor = new Productor2(cola);
        Consumidor2 consumidorSuma = new Consumidor2(cola, "suma");
        Consumidor2 consumidorProducto = new Consumidor2(cola, "producto");

        productor.start();
        consumidorSuma.start();
        consumidorProducto.start();
    }
}

