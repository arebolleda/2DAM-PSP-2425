import java.util.Random;

public class Productor2 extends Thread {
    private final Queue2 cola;

    public Productor2(Queue2 cola) {
        this.cola = cola;
    }

    @Override
    public void run() {
        Random random = new Random();
        try {
            for (int i = 0; i < 10; i++) {
                int numero = random.nextInt(10) + 1; // Números entre 1 y 100
                cola.put(numero);
                Thread.sleep(5); // Simula el tiempo de producción
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

