import java.util.concurrent.ArrayBlockingQueue;

public class Queue2 {
    private static final int CAPACIDAD = 5; 
    private final ArrayBlockingQueue<Integer> cola = new ArrayBlockingQueue<>(CAPACIDAD);
    private boolean sumaConsumida = true;
    private boolean productoConsumido = true;

    public synchronized void put(int numero) throws InterruptedException {
        while (!sumaConsumida || !productoConsumido) {
            System.out.println("Productor espera ...");
            wait(); // Espera hasta que ambos consumidores terminen
        }
        cola.put(numero);
        sumaConsumida = false;
        productoConsumido = false;
        System.out.println("Productor produce: " + numero);
        notifyAll(); // Notifica a los consumidores
    }

    public synchronized int get(String consumidor) throws InterruptedException {
        while (cola.isEmpty() || (consumidor.equals("suma") && sumaConsumida) || (consumidor.equals("producto") && productoConsumido)) {
            System.out.println(consumidor + " espera ...");
            wait(); // Espera a que haya algo para consumir
        }
        int numero = cola.peek(); // Mantiene el número en la cola hasta que ambos consumidores procesen
        if (consumidor.equals("suma")) {
            sumaConsumida = true;
        } else if (consumidor.equals("producto")) {
            productoConsumido = true;
        }

        if (sumaConsumida && productoConsumido) {
            cola.take(); // Elimina el número si ambos consumidores han terminado
        }

        notifyAll(); // Notifica al productor o al otro consumidor
        return numero;
    }
}

